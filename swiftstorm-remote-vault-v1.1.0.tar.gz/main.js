var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __markAsModule = (target) => __defProp(target, "__esModule", { value: true });
var __export = (target, all) => {
  __markAsModule(target);
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __reExport = (target, module2, desc) => {
  if (module2 && typeof module2 === "object" || typeof module2 === "function") {
    for (let key of __getOwnPropNames(module2))
      if (!__hasOwnProp.call(target, key) && key !== "default")
        __defProp(target, key, { get: () => module2[key], enumerable: !(desc = __getOwnPropDesc(module2, key)) || desc.enumerable });
  }
  return target;
};
var __toModule = (module2) => {
  return __reExport(__markAsModule(__defProp(module2 != null ? __create(__getProtoOf(module2)) : {}, "default", module2 && module2.__esModule && "default" in module2 ? { get: () => module2.default, enumerable: true } : { value: module2, enumerable: true })), module2);
};
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};

// main.ts
__export(exports, {
  default: () => swiftStormRemoteVaultPlugin
});
var import_obsidian = __toModule(require("obsidian"));
var DEFAULT_SETTINGS = {
  username: "",
  webhookUrl: "http://212.67.13.115:3005",
  autoSync: false,
  syncOnChange: true,
  conflictResolution: "date",
  lastSyncTime: 0,
  telegramUsername: "",
  confirmationToken: "",
  isRegistered: false
};
var swiftStormRemoteVaultPlugin = class extends import_obsidian.Plugin {
  constructor() {
    super(...arguments);
    this.isConnected = false;
  }
  onload() {
    return __async(this, null, function* () {
      yield this.loadSettings();
      const ribbonIconEl = this.addRibbonIcon("dice", "swiftStorm Remote Vault", (evt) => {
        new import_obsidian.Notice("swiftStorm Remote Vault \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D!");
      });
      this.addCommand({
        id: "sync-swiftstorm-vault",
        name: "\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 swiftStorm",
        callback: () => {
          this.syncVault();
        }
      });
      this.addCommand({
        id: "open-swiftstorm-settings",
        name: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 swiftStorm",
        callback: () => {
          this.app.setting.open();
          this.app.setting.openTabById(this.manifest.id);
        }
      });
      this.addSettingTab(new swiftStormSettingTab(this.app, this));
      this.registerDomEvent(document, "click", (evt) => {
        console.log("click", evt);
      });
      this.registerInterval(window.setInterval(() => console.log("setInterval"), 5 * 60 * 1e3));
      if (this.settings.autoSync && this.settings.isRegistered) {
        setTimeout(() => {
          this.syncVault();
        }, 2e3);
      }
      if (this.settings.isRegistered) {
        this.registerInterval(window.setInterval(() => {
          if (this.settings.syncOnChange) {
            this.syncVault();
          }
        }, 5 * 60 * 1e3));
      }
      if (this.settings.isRegistered && this.settings.syncOnChange) {
        this.registerEvent(this.app.vault.on("create", (file) => {
          this.uploadFileToServer(file);
        }));
        this.registerEvent(this.app.vault.on("modify", (file) => {
          this.uploadFileToServer(file);
        }));
        this.registerEvent(this.app.vault.on("delete", (file) => {
          this.deleteFileFromServer(file);
        }));
        this.registerEvent(this.app.vault.on("rename", (file, oldPath) => {
          this.renameFileOnServer(file, oldPath);
        }));
      }
      console.log("swiftStorm Remote Vault plugin \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D");
    });
  }
  onunload() {
    this.disconnect();
    console.log("swiftStorm Remote Vault plugin \u0432\u044B\u0433\u0440\u0443\u0436\u0435\u043D");
  }
  loadSettings() {
    return __async(this, null, function* () {
      this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
    });
  }
  saveSettings() {
    return __async(this, null, function* () {
      yield this.saveData(this.settings);
    });
  }
  registerViaTelegram() {
    return __async(this, null, function* () {
      if (!this.settings.telegramUsername) {
        new import_obsidian.Notice("\u274C \u0423\u043A\u0430\u0436\u0438\u0442\u0435 Telegram username \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445");
        return;
      }
      try {
        new import_obsidian.Notice("\u{1F504} \u041E\u0442\u043F\u0440\u0430\u0432\u043A\u0430 \u0437\u0430\u043F\u0440\u043E\u0441\u0430 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u044F \u0432 Telegram...");
        const response = yield fetch(`${this.settings.webhookUrl}/obsidian-sync`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            telegramUsername: this.settings.telegramUsername
          })
        });
        if (response.ok) {
          const data = yield response.json();
          if (data.status === "confirmation_sent") {
            this.settings.confirmationToken = data.token;
            yield this.saveSettings();
            new import_obsidian.Notice('\u2705 \u0417\u0430\u043F\u0440\u043E\u0441 \u043E\u0442\u043F\u0440\u0430\u0432\u043B\u0435\u043D! \u041F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 Telegram \u0438 \u043D\u0430\u0436\u043C\u0438\u0442\u0435 "\u042D\u0442\u043E \u044F"');
            this.pollConfirmationStatus();
          } else {
            new import_obsidian.Notice(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438: ${data.error || "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u043E\u0448\u0438\u0431\u043A\u0430"}`);
          }
        } else {
          const errorData = yield response.json();
          new import_obsidian.Notice(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0430: ${errorData.error || "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u043E\u0448\u0438\u0431\u043A\u0430"}`);
        }
      } catch (error) {
        console.error("\u041E\u0448\u0438\u0431\u043A\u0430 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438:", error);
        new import_obsidian.Notice(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u0435\u0442\u0438: ${error.message}`);
      }
    });
  }
  pollConfirmationStatus() {
    return __async(this, null, function* () {
      if (!this.settings.confirmationToken)
        return;
      const maxAttempts = 30;
      let attempts = 0;
      const poll = () => __async(this, null, function* () {
        attempts++;
        try {
          const response = yield fetch(`${this.settings.webhookUrl}/get-credentials`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              token: this.settings.confirmationToken
            })
          });
          if (response.ok) {
            const data = yield response.json();
            if (data.status === "confirmed") {
              if (data.username) {
                this.settings.username = data.username;
              }
              this.settings.isRegistered = true;
              this.settings.confirmationToken = "";
              yield this.saveSettings();
              new import_obsidian.Notice("\u2705 \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E! \u0414\u0430\u043D\u043D\u044B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B.");
              yield this.syncVault();
              return;
            } else if (data.status === "rejected") {
              new import_obsidian.Notice("\u274C \u041F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u043E");
              this.settings.confirmationToken = "";
              yield this.saveSettings();
              return;
            }
          }
          if (attempts < maxAttempts) {
            setTimeout(poll, 1e4);
          } else {
            new import_obsidian.Notice("\u23F0 \u0412\u0440\u0435\u043C\u044F \u043E\u0436\u0438\u0434\u0430\u043D\u0438\u044F \u0438\u0441\u0442\u0435\u043A\u043B\u043E");
            this.settings.confirmationToken = "";
            yield this.saveSettings();
          }
        } catch (error) {
          console.error("\u041E\u0448\u0438\u0431\u043A\u0430 \u043E\u043F\u0440\u043E\u0441\u0430 \u0441\u0442\u0430\u0442\u0443\u0441\u0430:", error);
          if (attempts < maxAttempts) {
            setTimeout(poll, 1e4);
          }
        }
      });
      poll();
    });
  }
  syncVault() {
    return __async(this, null, function* () {
      var _a, _b, _c, _d;
      if (!this.settings.username) {
        new import_obsidian.Notice("\u274C \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435\u0441\u044C \u0447\u0435\u0440\u0435\u0437 Telegram");
        return;
      }
      try {
        new import_obsidian.Notice("\u{1F504} \u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u0441 swiftStorm \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435\u043C...");
        const response = yield fetch(`${this.settings.webhookUrl}/sync-vault`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            username: this.settings.username
          })
        });
        if (response.ok) {
          const data = yield response.json();
          if (data.status === "success") {
            if (data.vault.folders) {
              for (const folder of data.vault.folders) {
                yield this.app.vault.createFolder(folder).catch(() => {
                });
              }
            }
            if (data.vault.files) {
              for (const file of data.vault.files) {
                const filePath = file.name;
                const content = file.content || `# ${file.name}

\u0424\u0430\u0439\u043B \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D \u0441 swiftStorm \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0430.`;
                try {
                  yield this.app.vault.create(filePath, content);
                } catch (error) {
                  const existingFile = this.app.vault.getAbstractFileByPath(filePath);
                  if (existingFile) {
                    yield this.app.vault.modify(existingFile, content);
                  }
                }
              }
            }
            this.settings.lastSyncTime = Date.now();
            yield this.saveSettings();
            this.isConnected = true;
            new import_obsidian.Notice(`\u2705 \u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u0443\u0441\u043F\u0435\u0448\u043D\u0430! \u041F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${((_a = data.vault.files) == null ? void 0 : _a.length) || 0} \u0444\u0430\u0439\u043B\u043E\u0432`);
            const statusFile = `\u{1F4CB} \u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 swiftStorm.md`;
            const statusContent = `# \u{1F517} swiftStorm Remote Vault

## \u{1F4CA} \u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u043E \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438

**\u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C:** ${data.username}  
**\u0421\u0442\u0430\u0442\u0443\u0441:** \u2705 \u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043E  
**\u0412\u0440\u0435\u043C\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438:** ${new Date().toLocaleString()}  
**\u0424\u0430\u0439\u043B\u043E\u0432 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E:** ${((_b = data.vault.files) == null ? void 0 : _b.length) || 0}  
**\u041F\u0430\u043F\u043E\u043A \u0441\u043E\u0437\u0434\u0430\u043D\u043E:** ${((_c = data.vault.folders) == null ? void 0 : _c.length) || 0}

## \u{1F4C1} \u0421\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430 \u043F\u0430\u043F\u043E\u043A

${((_d = data.vault.folders) == null ? void 0 : _d.map((folder) => `- **\u{1F4C1} ${folder}/**`).join("\n")) || "\u041F\u0430\u043F\u043A\u0438 \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B"}

## \u{1F680} \u0412\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0438

- \u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u0444\u0430\u0439\u043B\u043E\u0432 \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430
- \u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u0435 \u043F\u0440\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F\u0445
- \u041E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u043E\u0432 \u043F\u043E \u043F\u0430\u043F\u043A\u0430\u043C
- \u0420\u0435\u0437\u0435\u0440\u0432\u043D\u043E\u0435 \u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0432 \u043E\u0431\u043B\u0430\u043A\u0435

---
*\u0421\u043E\u0437\u0434\u0430\u043D\u043E \u043F\u043B\u0430\u0433\u0438\u043D\u043E\u043C swiftStorm Remote Vault v2.0*
`;
            try {
              yield this.app.vault.create(statusFile, statusContent);
            } catch (error) {
              const existingFile = this.app.vault.getAbstractFileByPath(statusFile);
              if (existingFile) {
                yield this.app.vault.modify(existingFile, statusContent);
              }
            }
          } else {
            new import_obsidian.Notice(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438: ${data.error || "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u043E\u0448\u0438\u0431\u043A\u0430"}`);
          }
        } else {
          const errorData = yield response.json();
          new import_obsidian.Notice(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0430: ${errorData.error || "\u041D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u0430\u044F \u043E\u0448\u0438\u0431\u043A\u0430"}`);
        }
      } catch (error) {
        console.error("\u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438:", error);
        new import_obsidian.Notice(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0441\u0435\u0442\u0438: ${error.message}`);
      }
    });
  }
  isConnectedToVault() {
    return this.isConnected;
  }
  uploadFileToServer(file) {
    return __async(this, null, function* () {
      if (!this.settings.isRegistered || !this.settings.syncOnChange)
        return;
      if (file.path.includes("\u{1F4CB} \u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 swiftStorm.md"))
        return;
      try {
        const content = yield this.app.vault.read(file);
        const response = yield fetch(`${this.settings.webhookUrl}/upload-file`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            username: this.settings.username,
            filePath: file.path,
            content
          })
        });
        if (response.ok) {
          console.log(`\u2705 \u0424\u0430\u0439\u043B \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440: ${file.path}`);
        } else {
          console.error(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u0444\u0430\u0439\u043B\u0430: ${file.path}`);
        }
      } catch (error) {
        console.error(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0435 \u0444\u0430\u0439\u043B\u0430 ${file.path}:`, error);
      }
    });
  }
  deleteFileFromServer(file) {
    return __async(this, null, function* () {
      if (!this.settings.isRegistered || !this.settings.syncOnChange)
        return;
      if (file.path.includes("\u{1F4CB} \u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 swiftStorm.md"))
        return;
      try {
        const response = yield fetch(`${this.settings.webhookUrl}/delete-file`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            username: this.settings.username,
            filePath: file.path
          })
        });
        if (response.ok) {
          console.log(`\u2705 \u0424\u0430\u0439\u043B \u0443\u0434\u0430\u043B\u0435\u043D \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430: ${file.path}`);
        } else {
          console.error(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u044F \u0444\u0430\u0439\u043B\u0430: ${file.path}`);
        }
      } catch (error) {
        console.error(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0438 \u0444\u0430\u0439\u043B\u0430 ${file.path}:`, error);
      }
    });
  }
  renameFileOnServer(file, oldPath) {
    return __async(this, null, function* () {
      if (!this.settings.isRegistered || !this.settings.syncOnChange)
        return;
      if (file.path.includes("\u{1F4CB} \u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 swiftStorm.md") || oldPath.includes("\u{1F4CB} \u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438 swiftStorm.md"))
        return;
      try {
        const content = yield this.app.vault.read(file);
        const response = yield fetch(`${this.settings.webhookUrl}/rename-file`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            username: this.settings.username,
            oldPath,
            newPath: file.path,
            content
          })
        });
        if (response.ok) {
          console.log(`\u2705 \u0424\u0430\u0439\u043B \u043F\u0435\u0440\u0435\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440\u0435: ${oldPath} -> ${file.path}`);
        } else {
          console.error(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0435\u0440\u0435\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u044F \u0444\u0430\u0439\u043B\u0430: ${oldPath} -> ${file.path}`);
        }
      } catch (error) {
        console.error(`\u274C \u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043F\u0435\u0440\u0435\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u043D\u0438\u0438 \u0444\u0430\u0439\u043B\u0430 ${oldPath} -> ${file.path}:`, error);
      }
    });
  }
};
var swiftStormSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "swiftStorm Remote Vault \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438" });
    new import_obsidian.Setting(containerEl).setName("\u0421\u0442\u0430\u0442\u0443\u0441 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F").addText((text) => text.setValue(this.plugin.settings.isRegistered ? "\u2705 \u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D" : "\u274C \u041D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D").setDisabled(true));
    new import_obsidian.Setting(containerEl).setName("Telegram Username").setDesc("\u0412\u0430\u0448 Telegram username (\u0431\u0435\u0437 @)").addText((text) => text.setPlaceholder("your_telegram_username").setValue(this.plugin.settings.telegramUsername).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.telegramUsername = value;
      yield this.plugin.saveSettings();
    })));
    if (this.plugin.settings.username) {
      new import_obsidian.Setting(containerEl).setName("Username").setDesc("\u0412\u0430\u0448 username \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0435 swiftStorm (\u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u043F\u043E\u043B\u0443\u0447\u0435\u043D)").addText((text) => text.setValue(this.plugin.settings.username).setDisabled(true));
    }
    new import_obsidian.Setting(containerEl).setName("Webhook URL").setDesc("URL webhook \u0441\u0435\u0440\u0432\u0435\u0440\u0430 \u0434\u043B\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u0438").addText((text) => text.setPlaceholder("http://212.67.13.115:3005").setValue(this.plugin.settings.webhookUrl).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.webhookUrl = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("\u0410\u0432\u0442\u043E\u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u043F\u0440\u0438 \u0437\u0430\u043F\u0443\u0441\u043A\u0435").setDesc("\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u043F\u0440\u0438 \u0437\u0430\u043F\u0443\u0441\u043A\u0435 Obsidian").addToggle((toggle) => toggle.setValue(this.plugin.settings.autoSync).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.autoSync = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F \u043F\u0440\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0438").setDesc("\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0438 \u0444\u0430\u0439\u043B\u043E\u0432").addToggle((toggle) => toggle.setValue(this.plugin.settings.syncOnChange).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.syncOnChange = value;
      yield this.plugin.saveSettings();
    })));
    new import_obsidian.Setting(containerEl).setName("\u041F\u0440\u0438\u043E\u0440\u0438\u0442\u0435\u0442 \u043F\u0440\u0438 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0430\u0445").setDesc("\u041A\u0430\u043A\u043E\u0439 \u0444\u0430\u0439\u043B \u043E\u0441\u0442\u0430\u0432\u043B\u044F\u0442\u044C \u043F\u0440\u0438 \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0435 \u0432\u0435\u0440\u0441\u0438\u0439").addDropdown((dropdown) => dropdown.addOption("date", "\u041F\u043E \u0434\u0430\u0442\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F").addOption("size", "\u041F\u043E \u0440\u0430\u0437\u043C\u0435\u0440\u0443 \u0444\u0430\u0439\u043B\u0430").setValue(this.plugin.settings.conflictResolution).onChange((value) => __async(this, null, function* () {
      this.plugin.settings.conflictResolution = value;
      yield this.plugin.saveSettings();
    })));
    if (this.plugin.settings.lastSyncTime > 0) {
      new import_obsidian.Setting(containerEl).setName("\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u044F\u044F \u0441\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F").addText((text) => text.setValue(new Date(this.plugin.settings.lastSyncTime).toLocaleString()).setDisabled(true));
    }
    if (!this.plugin.settings.isRegistered && this.plugin.settings.telegramUsername) {
      new import_obsidian.Setting(containerEl).setName("\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435").setDesc("\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C\u0441\u044F \u0447\u0435\u0440\u0435\u0437 Telegram").addButton((btn) => btn.setButtonText("\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C\u0441\u044F \u0447\u0435\u0440\u0435\u0437 Telegram").onClick(() => {
        this.plugin.registerViaTelegram();
      }));
    }
    if (this.plugin.settings.isRegistered) {
      new import_obsidian.Setting(containerEl).setName("\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0446\u0438\u044F").setDesc("\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435 \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430").addButton((btn) => btn.setButtonText("\u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0445\u0440\u0430\u043D\u0438\u043B\u0438\u0449\u0435").onClick(() => {
        this.plugin.syncVault();
      }));
    }
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {});
